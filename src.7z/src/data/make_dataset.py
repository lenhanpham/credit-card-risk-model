import tensorflow as tf
from sklearn.datasets import fetch_openml

def load_credit_data():
    """Load the German credit dataset from OpenML"""
    credit_data = fetch_openml(name='credit-g', version=1, as_frame=True)
    X = credit_data.data
    y = credit_data.target.map({'good': 1, 'bad': 0}).values
    return X, y

def create_tf_datasets(X, y, train_size=0.7, val_size=0.15, batch_size=128, seed=None):
    """Create TensorFlow datasets for training, validation, and testing"""
    dataset = tf.data.Dataset.from_tensor_slices((dict(X), y))
    dataset = dataset.shuffle(buffer_size=len(X), seed=seed)
    n = len(X)
    train_size_n = int(n * train_size)
    val_size_n = int(n * val_size)
    
    train_dataset = dataset.take(train_size_n)
    val_dataset = dataset.skip(train_size_n).take(val_size_n)
    test_dataset = dataset.skip(train_size_n + val_size_n)
    
    return (
        train_dataset.batch(batch_size).prefetch(tf.data.AUTOTUNE),
        val_dataset.batch(batch_size).prefetch(tf.data.AUTOTUNE),
        test_dataset.batch(batch_size).prefetch(tf.data.AUTOTUNE)
    )
