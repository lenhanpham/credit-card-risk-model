"""
Configuration settings for the credit risk model
"""

# Feature definitions
DISCRETE_FEATURES = ['installment_commitment', 'residence_since', 'num_dependents', 'existing_credits']
CATEGORICAL_FEATURES = None  # Will be populated dynamically from data
CONTINUOUS_FEATURES = ['duration', 'credit_amount']

# Training parameters
BATCH_SIZE = 128
LEARNING_RATE = 0.001
MAX_EPOCHS = 200
EMBEDDING_SIZE = 8
RANDOM_SEED = 2025

# Hyperparameter tuning
HP_MAX_TRIALS = 200
HP_EXECUTIONS_PER_TRIAL = 1
HP_TUNING_DIR = 'models/hyperparameter_tuning'
HP_PROJECT_NAME = 'credit_risk'

# Model architecture search space
HP_UNITS1_MIN = 32
HP_UNITS1_MAX = 256
HP_UNITS1_STEP = 16

HP_UNITS2_MIN = 32
HP_UNITS2_MAX = 256
HP_UNITS2_STEP = 16

HP_DROPOUT_MIN = 0.0
HP_DROPOUT_MAX = 0.5
HP_DROPOUT_STEP = 0.05

HP_LR_MIN = 1e-5
HP_LR_MAX = 1e-2

# Callbacks
EARLY_STOPPING_PATIENCE = 15
LR_REDUCE_PATIENCE = 15
LR_REDUCE_FACTOR = 0.5
LR_REDUCE_MIN = 1e-6
CHECKPOINT_PATH = 'models/best_credit_risk_model.keras'
