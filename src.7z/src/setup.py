from setuptools import find_packages, setup

setup(
    name='credit_risk_model',
    packages=find_packages(),
    version='0.1.0',
    description='Credit risk prediction model using TensorFlow',
    author='Your Name',
    license='MIT',
)
