import tensorflow as tf
from tensorflow.keras.optimizers import Adam
from tensorflow.keras.callbacks import EarlyStopping, ReduceLROnPlateau, ModelCheckpoint
import keras_tuner as kt

from src.data.make_dataset import load_credit_data, create_tf_datasets
from src.features.preprocessor import CreditDataPreprocessor
from src.models.credit_risk_model import CreditRiskModel
from config.model_config import *

def build_model_for_tuning(hp, preprocessor):
    """Build model with hyperparameters for tuning"""
    # Instantiate the model
    model_instance = CreditRiskModel(preprocessor)

    continuous_inputs = {
        col: tf.keras.layers.Input(shape=(1,), dtype=tf.float32, name=f"{col}_input")
        for col in preprocessor.continuous_features
    }
    discrete_inputs = {
        col: tf.keras.layers.Input(shape=(1,), dtype=tf.int32, name=f"{col}_input")
        for col in preprocessor.discrete_features
    }
    categorical_inputs = {
        col: tf.keras.layers.Input(shape=(1,), dtype=tf.string, name=f"{col}_input")
        for col in preprocessor.categorical_features
    }

    # Call the instance method
    processed_features = model_instance._process_features(
        continuous_inputs, discrete_inputs, categorical_inputs
    )

    # Hyperparameters from search space
    hp_units1 = hp.Int('units1', min_value=HP_UNITS1_MIN, max_value=HP_UNITS1_MAX, step=HP_UNITS1_STEP)
    hp_units2 = hp.Int('units2', min_value=HP_UNITS2_MIN, max_value=HP_UNITS2_MAX, step=HP_UNITS2_STEP)
    hp_dropout = hp.Float('dropout', min_value=HP_DROPOUT_MIN, max_value=HP_DROPOUT_MAX, step=HP_DROPOUT_STEP)
    hp_learning_rate = hp.Float('learning_rate', min_value=HP_LR_MIN, max_value=HP_LR_MAX, sampling='log')

    x = tf.keras.layers.Dense(hp_units1, activation='relu', kernel_initializer='he_normal')(processed_features)
    x = tf.keras.layers.Dropout(hp_dropout)(x)
    x = tf.keras.layers.Dense(hp_units2, activation='relu', kernel_initializer='he_normal')(x)
    x = tf.keras.layers.Dropout(hp_dropout)(x)
    output = tf.keras.layers.Dense(1, activation='sigmoid')(x)

    model_inputs = list(continuous_inputs.values()) + list(discrete_inputs.values()) + list(categorical_inputs.values())
    model = tf.keras.models.Model(inputs=model_inputs, outputs=output)
    model.compile(optimizer=Adam(learning_rate=hp_learning_rate),
                  loss='binary_crossentropy',
                  metrics=['accuracy'])
    return model

def train_model():
    """Train the credit risk model"""
    # Load data
    X, y = load_credit_data()
    
    # Update categorical features from data
    global CATEGORICAL_FEATURES
    CATEGORICAL_FEATURES = X.select_dtypes(exclude='number').columns.tolist()
    
    # Create datasets
    train_dataset_raw, val_dataset_raw, test_dataset_raw = create_tf_datasets(
        X, y, batch_size=BATCH_SIZE, seed=RANDOM_SEED
    )
    
    # Initialize and adapt preprocessor
    preprocessor = CreditDataPreprocessor(
        discrete_features=DISCRETE_FEATURES,
        categorical_features=CATEGORICAL_FEATURES,
        continuous_features=CONTINUOUS_FEATURES
    )
    preprocessor.adapt(train_dataset_raw)
    
    # Prepare datasets
    train_dataset = preprocessor.prepare_dataset(train_dataset_raw)
    val_dataset = preprocessor.prepare_dataset(val_dataset_raw)
    test_dataset = preprocessor.prepare_dataset(test_dataset_raw)
    
    # Define callbacks
    callbacks = [
        EarlyStopping(
            patience=EARLY_STOPPING_PATIENCE, 
            restore_best_weights=True, 
            monitor='val_accuracy'
        ),
        ReduceLROnPlateau(
            monitor='val_accuracy', 
            factor=LR_REDUCE_FACTOR, 
            patience=LR_REDUCE_PATIENCE, 
            min_lr=LR_REDUCE_MIN
        ),
        ModelCheckpoint(
            CHECKPOINT_PATH, 
            monitor='val_accuracy', 
            save_best_only=True
        )
    ]
    
    # Hyperparameter tuning
    tuner = kt.RandomSearch(
        hypermodel=lambda hp: build_model_for_tuning(hp, preprocessor),
        objective='val_accuracy',
        max_trials=HP_MAX_TRIALS,
        executions_per_trial=HP_EXECUTIONS_PER_TRIAL,
        directory=HP_TUNING_DIR,
        project_name=HP_PROJECT_NAME
    )
    
    tuner.search_space_summary()
    tuner.search(train_dataset, epochs=MAX_EPOCHS, validation_data=val_dataset, callbacks=callbacks)
    
    # Get best hyperparameters and build final model
    best_hp = tuner.get_best_hyperparameters(1)[0]
    print(f"Best hyperparameters: {best_hp.values}")
    
    best_model = tuner.hypermodel.build(best_hp)
    best_model.fit(train_dataset, epochs=MAX_EPOCHS, validation_data=val_dataset, callbacks=callbacks)
    
    # Evaluate on test set
    test_loss, test_acc = best_model.evaluate(test_dataset)
    print(f"Test loss: {test_loss} - Test accuracy: {test_acc}")
    
    # Save the best model
    best_model.save('models/best_model_with_tuner.keras')
    
    return best_model, preprocessor

if __name__ == "__main__":
    # Silence TensorFlow warnings
    try:
        from silence_tensorflow import silence_tensorflow
        silence_tensorflow()
    except ImportError:
        print("silence_tensorflow not installed. Continuing with warnings.")
    
    # Train the model
    model, preprocessor = train_model()
